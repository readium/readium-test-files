navigator.epubReadingSystem = window.parent.navigator.epubReadingSystem;
